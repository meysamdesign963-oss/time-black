/**
 * POST /api/upload
 * ---------------
 * Secure file upload endpoint for images and videos.
 *
 * Security:
 *  - Whitelist MIME types
 *  - 2MB limit for images (site-wide), 50MB for videos
 *  - Random filenames (crypto.randomUUID)
 *  - Files stored in /public/uploads/{images,videos,avatars,covers}
 *  - Rate limited: 20 uploads per 5 minutes per user
 */
import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import crypto from "crypto";
import { getAuth } from "@/lib/route-helpers";
import { rateLimit, hasRestriction } from "@/utils/validation";
import { ok, fail, unauthorized, forbidden } from "@/utils/api-response";
import { db } from "@/lib/db";

// Allowed MIME types and their folder + max size
const ALLOWED: Record<
  string,
  { folder: string; maxSize: number; ext: string }
> = {
  "image/jpeg": { folder: "images", maxSize: 2 * 1024 * 1024, ext: "jpg" },
  "image/png": { folder: "images", maxSize: 2 * 1024 * 1024, ext: "png" },
  "image/webp": { folder: "images", maxSize: 2 * 1024 * 1024, ext: "webp" },
  "image/gif": { folder: "images", maxSize: 2 * 1024 * 1024, ext: "gif" },
  "video/mp4": { folder: "videos", maxSize: 50 * 1024 * 1024, ext: "mp4" },
  "video/webm": { folder: "videos", maxSize: 50 * 1024 * 1024, ext: "webm" },
};

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { user, applyRefresh } = await getAuth(request);
  if (!user) return unauthorized();

  // Check upload restriction
  const userWithRestrictions = await db.user.findUnique({
    where: { id: user.id },
    select: { restrictions: true },
  });
  if (userWithRestrictions && hasRestriction(userWithRestrictions.restrictions || "", "canUpload"))
    return forbidden("شما دسترسی آپلود ندارید");

  // Rate limit: 20 uploads per 5 minutes per user
  const rl = rateLimit(`upload:${user.id}`, 20, 5 * 60 * 1000);
  if (!rl.ok) {
    return fail("تعداد آپلودها بیش از حد مجاز است. بعداً تلاش کنید.", 429, {
      retryAfter: Math.ceil((rl.resetAt - Date.now()) / 1000),
    });
  }

  const formData = await request.formData();
  const file = formData.get("file");
  if (!file || !(file instanceof File)) {
    return fail("فایلی ارسال نشده است", 400);
  }

  const contentType = file.type;
  const config = ALLOWED[contentType];
  if (!config) {
    return fail(
      "فرمت فایل مجاز نیست. فقط jpg, png, webp, gif, mp4, webm پذیرفته می‌شود.",
      400,
    );
  }

  if (file.size > config.maxSize) {
    const maxMB = Math.round(config.maxSize / (1024 * 1024));
    return fail(
      `حجم فایل بیش از حد مجاز است. حداکثر ${maxMB} مگابایت.`,
      413,
    );
  }

  // Check for "type" field to route to avatar/cover folder
  const uploadType = formData.get("type") as string | null;
  const folder = uploadType === "avatar"
    ? "avatars"
    : uploadType === "cover"
      ? "covers"
      : config.folder;

  // Randomize filename to prevent path guessing
  const randomName = `${crypto.randomUUID()}.${config.ext}`;
  const uploadDir = path.join(process.cwd(), "public", "uploads", folder);
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true });
  }
  const filePath = path.join(uploadDir, randomName);

  // Read file as ArrayBuffer and write
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);
  await writeFile(filePath, buffer);

  // Public URL path
  const url = `/uploads/${folder}/${randomName}`;
  const mediaType = config.folder === "images" ? "IMAGE" : "VIDEO";

  const res = ok({
    url,
    mediaType,
    size: file.size,
    mimeType: contentType,
    folder,
  });
  return applyRefresh(res);
}
